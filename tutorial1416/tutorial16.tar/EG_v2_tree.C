/* 
   In this ROOT function we generate a distribution according to sin(x)
   between 0 and pi

   To run do:
   root 
   .L EG_v2.C+ 
   rootfuncgenerate(10000)
*/

// include C++ STL headers 
#include <iostream>
#include <fstream>

using namespace std;

// ROOT library obejcts
#include <TF1.h> // 1d function class
#include <TH1.h> // 1d histogram classes
#include <TStyle.h>  // style object
#include <TMath.h>   // math functions
#include <TCanvas.h> // canvas object
#include <TRandom.h>
#include <TTree.h>
#include <TClonesArray.h>
#include <TFile.h>
#include "MyClasses.C"

//Note: The function rootfuncgenerate doesn't always work for greater values of sigmaTracks.
//I found that it works well when sigmaTracks<=~1.

void rootfuncgenerate(Int_t nEvents, Int_t nTracks, Double_t sigmaTracks, Double_t v2, Double_t sigmaV2); // ROOT method (a bit dangerous since we don't know exactly what happens!)


//________________________________________________________________________
void rootfuncgenerate(Int_t nEvents, Int_t nTracks, Double_t sigmaTracks, Double_t v2, Double_t sigmaV2) 
{ 
  cout << "Generating " << nEvents << " events" << endl << endl;

  // create histogram that we will fill with random values
  TH1D* hPhi = new TH1D("hPhi", "ROOT func generated v2 distribution; phi; Counts", 
			100, 0, 2*TMath::Pi());
        
  Double_t phi[nTracks]; //array to store phi angles

  //Open output file
  ofstream file1("phi_dist.dat");
  
  // Create the outfile and data structure before the loop
  TFile* file = new TFile("phi_dist.root", "RECREATE");
  TTree* tree = new TTree("tree", "Output tree");
  MyEvent* event = new MyEvent();
  tree->Branch("event", &event);
  TClonesArray* trackArray = new TClonesArray("MyTrack", 1000);
  tree->Branch("track", "TClonesArray", &trackArray);
  Int_t nT = 0;
  
  // make a loop for the number of events
  for(Int_t n = 0; n < nEvents; n++) {
    
    Int_t nTracksEvents = gRandom->Gaus(nTracks,sigmaTracks);
    Double_t v2Events = gRandom->Gaus(v2,sigmaV2);
    
    // In the generate loop: for each event set nTracks and fV2
    event->nTracks = nTracksEvents;
    event->fV2 = v2Events;
    
	// Define the function we want to generate
	TF1* v2Func = new TF1("v2Func", "1+2*[1]*cos(2*x)", 0, 2*TMath::Pi());
	v2Func->SetParameter(1, v2Events);
    
    //generate nTracks phi angles
	for (Int_t nt = 0; nt < nTracksEvents; nt++) {
	  
		//Fill the array
		phi[nt] = v2Func->GetRandom();
		
		// In the track loop: for each track
		MyTrack* track = new((*trackArray)[nt]) MyTrack();
		//nT++;
		track->fPhi = phi[nt];
	}
    
    if((n+1)%1000==0)
      cout << "event " << n+1 << endl;
    
    file1 << "Event " << n << endl;
    file1 << "nTracks " << nTracks << endl;
    
	//Fill out hPhi hist
	for (Int_t i = 0; i < nTracks; i++) {
	  
	  hPhi->Fill(phi[i]);
	  file1 << i << " : " << phi[i] << endl;
	}
	
	// In the end of each event loop
	tree->Fill();
	trackArray->Clear(); // reset the array but do not delete memory
  }
  
  // After all the generation is done
  file->Write();
  file->Close();
  
  //close file
  file1.close();

  // Set ROOT drawing styles
  gStyle->SetOptStat(1111);
  gStyle->SetOptFit(1111);

  // create canvas for hSin
  TCanvas* c1 = new TCanvas("c1", "v2 canvas", 900, 600);
  hPhi->SetMinimum(0);
  hPhi->Draw();
  
  // create 1d function that we will use to fit our generated data to ensure
  // that the generation works
  TF1* fitFunc = new TF1("fitFunc", "[0]*(1+2*[2]*(cos(2*x)))", 0, 2*TMath::Pi());
  fitFunc->SetParameter(0, 10);
  fitFunc->SetParameter(2, v2);
  fitFunc->SetLineColor(kRed);
  hPhi->Fit(fitFunc);
  
  // Save the canvas as a picture
  c1->SaveAs("v2_rootfunc.jpg");
}
